package com.tccagil.tcc1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tcc1Application {

	public static void main(String[] args) {
		SpringApplication.run(Tcc1Application.class, args);
	}

}
